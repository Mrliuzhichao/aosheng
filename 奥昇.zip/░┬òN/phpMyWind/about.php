<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 2 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link rel="stylesheet" type="text/css" href="Css/scheme.css">
<link rel="stylesheet"  href="Css/project.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<div class="divName">
		<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE  classid=17 AND flag LIKE '%h%' AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
            <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"  width="80%" height="200px">
        <?php
			}
			?>

 </div>
<!-- /banner-->

<!-- mainbody-->

<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=17  AND  flag LIKE '%a%'  AND  delstate='' AND checkinfo=true ORDER BY orderid ASC   LIMIT 0,3");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>	
			
	
	<div class="cheek">
	 	<div class="cheek1">
		<img src="<?php echo $row['picurl']; ?>" alt="">
		</div> 
		<div class="add"><?php echo $row['description']; ?> </div>
		
		
		</div>
			


			<?php
			}
			?>
					
        

     

<!-- /mainbody-->
<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>