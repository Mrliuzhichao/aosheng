<?php	if(!defined('IN_MOBILE')) exit('Request Error!'); ?>
<div class="footer"> © 2017 PHPMyWind </div>
