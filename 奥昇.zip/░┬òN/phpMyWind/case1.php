<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 21 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link rel="stylesheet"  href="Css/me.css">
<link rel="stylesheet"  href="Css/project.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".caselist a.img img").LoadImage({width:100,height:80});
});
</script>
</head>
<body>
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE  classid=20 AND flag LIKE '%h%' AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
            <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"  width="100%" height="300px;">
        <?php
			}
			?>

<div class="print">公司简介</div>
<div class="print1">您当前所在位置:首页>关于我们>公司简介</div>
<div class="print2"></div>

	<div class="me">

<div class="me1"><a href="case.php">关于我们/About Us</a></div>

	
	<div class="me2">

	<ul>
	<li>公司简介</li>
	<li>荣誉资质</li>
	<li>企业文化</li>
	<li>董事长致辞</li>
	<li>公司风采</li>
	<li>合作伙伴</li>
	<li>公司地址</li>
	</ul>
	</div>
	</div>
	<div class="Maname">
	<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE  classid=21 AND flag LIKE '%a%' AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
            <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" ">
        <?php
			}
			?>
</div>

				<div class="plate2">
		奥昇所获荣誉资质
		</div>
		<div class="plate3">
		 <ul>
		 	<li>奥昇 智慧教育-三通两平台主站系统</li>
		 	<li>网络学习人人通</li>
		 	<li>智慧教育-家校互联网软件 (APP-Andriod)</li>
		 	<li>智慧教育-家校互联网软件(APP-IOS)</li>
		 	<li>智慧教育-教育资源中心系统</li>
		 	<li>智慧教育-授课软件</li>
		 	<li>智慧教育-数字校园管理平台</li>
		 	<li>智慧教育-同步助手软件(APP-Andriod)</li>
		 	<li>智慧教育-云盘管理系统(APP-IOS)</li>
		 	<li>智慧演示系统</li>
		 </ul>
		</div>

<?php require_once('footer.php'); ?>
</body>
</html>