<!-- weblink-->

		<div class="under1">

	<div class="base1s"><img src="images/header-logo.png"></div>
	<div class="base2s"><img src="images/houpu_code.png" class="tpa"></div>


	<p>合作热线：4008745099 18307459777 公司地址：湖南省怀化市鹤城区河西市政协大楼6
	<p>Copyright © 2014 - 2015 aorise.com All Rights Reserved网站备案 湘ICP备15016651号。</p>
	<p>本栏目文字内容归aorise.cn 所有,任何单位及个人未经许可，不得擅自转摘使用。</p>
	</div>
